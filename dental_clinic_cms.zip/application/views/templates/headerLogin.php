<!DOCTYPE html>
<html lang="en">
<head>
    <title>SISTEMA DE NOTAS CDS</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo RUTA_URL; ?>/img/icons/test.png"/>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo RUTA_URL; ?>/assets/css/bootstrap.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo RUTA_URL; ?>/assets/font-awesome/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo RUTA_URL; ?>/css/login/util.css">
    <link rel="stylesheet" type="text/css" href="<?php echo RUTA_URL; ?>/css/login/login.css">
    <!--===============================================================================================-->
</head>
<body>
