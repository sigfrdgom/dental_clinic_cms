    <!-- End of page container -->
    </div>

    <!-- Start of minimalist footer -->
    <footer class="footer text-center">
        © CLIDESA CMS
    </footer>
    <!-- End of minimalist footer -->

    
    <!-- JS import's -->
    <script src="<?= base_url('assets/jquery/jquery-3.4.1.min.js')?>"></script>
	<script src="<?= base_url('assets/popper/popper.min.js')?>"></script>

    <script src="<?= base_url('assets/css/bootstrap/dist/js/bootstrap.min.js')?>"></script>
    
    
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?= base_url('assets/js/perfect-scrollbar.jquery.min.js')?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/js/waves.js')?>"></script>
    <!--Menu sidebar -->
    <script src="<?= base_url('assets/js/sidebarmenu.js')?>"></script>
    <!--Custom JavaScript -->
    <script src="<?= base_url('assets/js/custom.min.js')?>"></script>
    <!-- Chart JS -->
    <script src="<?= base_url('assets/js/dashboard1.js')?>"></script>
    
    <!-- Own JS files -->
	
</body>

</html>
